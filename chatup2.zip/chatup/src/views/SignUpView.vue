<template>

    <h1> Register Page</h1>
  
</template>
<script>
    export default{
        name:'SignUpView'
    }
</script>

<style scoped>


</style>