<template>

    <h1>This is Contact Page</h1>
  
</template>
<script>
    export default{
        name:'ContactUsView'
    }
</script>



<style scoped>


</style>