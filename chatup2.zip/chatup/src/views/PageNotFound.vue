<template>

<div class= "container text-center  text-danger mt-3">
    <div class="row">
        <div class="col">
            <h1>Page Not Found</h1> 
        </div>
    </div>

</div>
  
</template>
<script>
    export default{
        name:'PageNotFound'
    }
</script>



<style scoped>


</style>