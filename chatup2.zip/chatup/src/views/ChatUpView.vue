<template>

    <h1>This is the chat page</h1>
  
</template>


<script>
    export default{
        name:'ChatUpView'
    }
</script>



<style scoped>


</style>