<template>
  <div id="app">
    <NavBarView/>
    <router-view/>
    <FooterView/>
  </div>
</template>

<script > 
import NavBarView from './components/NavBarView.vue'
import FooterView from './components/FooterView.vue'


export default{
    components: { NavBarView, FooterView},
    name: 'App'
  }
</script>

<style>
@import url('https://fonts.googleapis.com/css2?family=Poppins&family=Roboto:wght@700&display=swap');
#app{
  font-family: Poppins;
}
</style>



