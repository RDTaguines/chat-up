<template>
  <div id="app">
    <NavBarView/>
    <router-view/>
  </div>
</template>

<script > 
import NavBarView from './components/NavBarView.vue'

export default{
    components: { NavBarView },
    name: 'App'
  }
</script>
<style>
@import url('https://fonts.googleapis.com/css2?family=Poppins&family=Roboto:wght@700&display=swap');
#app{
  font-family: Poppins;
}
</style>



