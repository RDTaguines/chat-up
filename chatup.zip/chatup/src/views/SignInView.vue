<template>

    <h1>LoginPage</h1>

</template>
<script>
    export default{
        name:'SignInView'
    }
</script>



<style scoped>


</style>