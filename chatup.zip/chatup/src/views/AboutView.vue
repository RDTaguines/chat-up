<template>
    <div class="about-us">
        <div class="container mt-5">
            <div class="row">
                <div class="col-lg-6 text-center gr-2">
                    <h2 class="container__about-heading">ABOUT US</h2>
                    <p class="container__sub-about">We're a chat application that allows you to talk to your friends, 
                    family, and anyone else you want to talk to from anywhere at any time. 
                    You can send messages, photos, videos, or whatever else you want!

                    You can use this app on your phone as well as from your computer.<br>
                    There's no need to install anything—you can just sign up and start chatting!
                    </p>
                </div>

                
                <div class="col-lg-6">
                    <img class="container__img text-center" src="../assets/about-img.png" alt="head">
                </div>
            </div>
        </div>
    </div>

    <div class="feature">
        <div class="container mb-5">
            <h2 class=" container__feature-heading text-center">WE ARE THE BEST SOLUTION FOR YOUR COMMUNICATION</h2>
            <p class="container__feature-subHeading text-center">There are already more than 3 MILLION users around the world!</p>
            <div class="row">
                <div class="col-lg-4 text-center">
                    <img class="container__feat-img" src="../assets/feat1.png" alt="head">
                    <h4 class="container__feat-subName text-center">FREE PREMIUM FEATURES</h4>
                </div>
                <div class="col-lg-4 text-center">
                    <img class="container__feat-img" src="../assets/feat2.png" alt="head">
                    <h4 class="container__feat-subName">REAL-TIME PUSH MESSAGE</h4>
                </div>
                <div class="col-lg-4 text-center">
                    <img class="container__feat-img" src="../assets/feat3.png" alt="head">
                    <h4 class="container__feat-subName">EASY TO USE INTERFACE</h4>
                </div>
            </div>
        </div>
    </div>
    

</template>
<script>
    export default{
        name:'AboutView'
    }
</script>

<style lang="scss" scoped>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;900&family=Roboto:wght@700&display=swap');
    @import './src/styles/_variables.scss';
    @import './src/styles/_header.scss';
    @import './src/styles/style.scss';
    @import './src/styles/_buttons.scss';

.about-us{

    .container{

        &__about-heading{
            color:$primaryColor;
            margin-top:8.5rem;
        }

        &__sub-about{
            margin-top:2.5rem;
        }

        &__img{
            height:27rem;
            width: 27rem;
            margin-top:5rem;
        }
    }
}

.feature{
    margin-top: 10rem;
    

    .container{

        &__feature-heading{
            color:$primaryColor;
        }

        &__feat-img{
            height: 10rem;
            width: 10rem;
            margin-top:2.5rem;
        }

        &__feat-subName{
            font-size: 1.5rem;
            font-weight: 600;
            margin-top:0.8rem;
            }
    }
}

.row{
    margin-top: 3rem;
}
</style>

