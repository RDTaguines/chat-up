<template>
  <div class="wrapper">
    <div class="home">
      <h1 class="heroSection">The world is closer <br>than ever with <span>CHATUP</span></h1>
      <h4>The best way to keep in touch with your friends anywhere in the world!</h4>    
      <HelloWorld msg="Welcome to Your Vue.js App"/>
    </div>
    <div class="buttons">
      <button class="btn1">SIGN-IN</button>
      <button class="btn2">SIGN-UP</button>
    </div>
  </div>
</template>

<script>
// @ is an alias to /src

export default {
  name: 'HomeView',
}
</script>
<style lang="scss" scoped>
  @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;900&family=Roboto:wght@700&display=swap');
  @import './src/styles/_variables.scss';
  @import './src/styles/_header.scss';
  @import './src/styles/style.scss';
  @import './src/styles/_buttons.scss';

  .wrapper{
    background: url(../assets/banner.png);
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
    min-height: 35.625rem;
  }

  div.home {
    @include centerEvrything();
  }
    div h1.heroSection{
      font-family: 'Poppins', sans-serif;
      color: $primaryColor;
      line-height: 1em;
    }
    h1.heroSection span{
      color: $btnColor;
    }
  div.buttons{
    @include centerBtn();
  }
    div button{
      @include btnFormat();
    }
      button.btn1{
        background-color: $accentColor;
      }
      button.btn2{
        background-color: $btnColor;
      }
</style>