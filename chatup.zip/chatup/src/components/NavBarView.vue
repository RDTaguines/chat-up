<template>
<div class="container-fluid navbar navbar-expand navbar-light bg-light">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">Logo Here</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse justify-content-center" id="navbarSupportedContent" >
            <div class="navbar-nav mr-auto text-end">
                <router-link to="/" class="nav-item nav-link">Home</router-link>
                <router-link to="/About" class="nav-item nav-link">About</router-link>
                <router-link to="/Contact" class="nav-item nav-link">Contact</router-link>
                <!-- <router-link to="/ChatUp" class="nav-link">ChatUp</router-link>
                <router-link to="/SignIn" class="nav-link">Login</router-link>
                <router-link to="/SignUp" class="nav-link">Sign Up</router-link> -->
            </div>
        </div>
    </div>
</div>
</template>

<script>
    export default{
        name:'NavBarViewVue '
    }
</script>

<style lang="scss">
@import './src/styles/_navigation.scss';
@import './src/styles/_variables.scss';

.nav-item {
    @include navItem();
}
div.navbar {
    background-color: $accentColor !important;
}
</style>



